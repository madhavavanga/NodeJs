var http = require("http");
var fs = require("fs");
const config = require("./config.json");

var server = http.createServer(function(req, res){
    fs.readFile("./public/"+req.url, function(error, data){
        if(data){
            res.writeHead(200, {"Content-Type":"text/html"});
            var pdata = data.toString();
                pdata = pdata.replace("{{message}}", config.message )
            res.end(pdata);
        }else{
            res.writeHead(404, {"Content-Type":"text/plain"});
            res.end("Request Page Not Found");
        }
    })
});

server.listen(config.config.port, config.config.host, function(){
    console.log("server is running on port "+config.config.port)
});